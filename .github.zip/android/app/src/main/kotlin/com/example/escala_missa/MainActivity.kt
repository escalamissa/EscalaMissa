package com.example.escala_missa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
