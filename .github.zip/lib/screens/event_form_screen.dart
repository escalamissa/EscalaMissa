import 'package:escala_missa/models/event.dart';
import 'package:escala_missa/models/parish.dart';
import 'package:escala_missa/services/event_service.dart';
import 'package:escala_missa/services/liturgical_calendar_service.dart';
import 'package:escala_missa/services/parish_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

class EventFormScreen extends StatefulWidget {
  final Evento? evento; // Corrigido para Evento
  const EventFormScreen({super.key, this.evento});

  @override
  State<EventFormScreen> createState() => _EventFormScreenState();
}

class _EventFormScreenState extends State<EventFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleController;
  late TextEditingController _descricaoController;
  late TextEditingController _localController;
  late TextEditingController _tempoLiturgicoController;
  late TextEditingController _solenidadeController;

  String? _selectedParishId;
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  final EventService _eventService = EventService();
  final ParishService _parishService = ParishService();
  final LiturgicalCalendarService _liturgicalCalendarService =
      LiturgicalCalendarService();
  List<Parish> _parishes = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.evento?.titulo ?? '');
    // CORREÇÃO: Usa 'descricao' do modelo
    _descricaoController = TextEditingController(
      text: widget.evento?.descricao ?? '',
    );
    _localController = TextEditingController(text: widget.evento?.local ?? '');
    _tempoLiturgicoController = TextEditingController(
      text: widget.evento?.tempoLiturgico ?? '',
    );
    _solenidadeController = TextEditingController(
      text: widget.evento?.solenidade ?? '',
    );

    if (widget.evento != null) {
      _selectedParishId = widget.evento!.paroquiaId;
      final dateTime = DateTime.parse(widget.evento!.data_hora);
      _selectedDate = DateTime(dateTime.year, dateTime.month, dateTime.day);
      _selectedTime = TimeOfDay(hour: dateTime.hour, minute: dateTime.minute);
    }

    _fetchDependencies();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descricaoController.dispose();
    _localController.dispose();
    _tempoLiturgicoController.dispose();
    _solenidadeController.dispose();
    super.dispose();
  }

  Future<void> _fetchDependencies() async {
    setState(() => _isLoading = true);
    try {
      _parishes = await _parishService.getParishes();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar paróquias: $e')),
        );
      }
    }
    setState(() => _isLoading = false);
  }

  Future<void> _fetchLiturgicalData(DateTime date) async {
    try {
      final liturgicalData = await _liturgicalCalendarService.getLiturgicalData(
        date,
      );
      if (mounted && liturgicalData != null) {
        setState(() {
          _tempoLiturgicoController.text =
              liturgicalData['liturgia']?.toString() ?? '';
          final solenidade = liturgicalData['solenidade'];
          _solenidadeController.text = solenidade is Map
              ? solenidade['nome']?.toString() ?? ''
              : solenidade?.toString() ?? '';
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Erro ao buscar liturgia: $e')));
      }
    }
  }

  Future<void> _saveEvent() async {
    if (_formKey.currentState!.validate()) {
      if (_selectedParishId == null ||
          _selectedDate == null ||
          _selectedTime == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Por favor, preencha todos os campos obrigatórios.'),
          ),
        );
        return;
      }

      setState(() => _isLoading = true);
      try {
        final fullDateTime = DateTime(
          _selectedDate!.year,
          _selectedDate!.month,
          _selectedDate!.day,
          _selectedTime!.hour,
          _selectedTime!.minute,
        );

        // Cria o objeto Evento com os dados corretos
        final eventoData = Evento(
          id: widget.evento?.id ?? '', // ID vazio para criação
          paroquiaId: _selectedParishId!,
          titulo: _titleController.text.trim(),
          descricao: _descricaoController.text.trim(), // Corrigido
          data_hora: fullDateTime.toIso8601String(),
          local: _localController.text.trim(),
          tempoLiturgico: _tempoLiturgicoController.text.trim(),
          solenidade: _solenidadeController.text.trim(),
        );

        // SIMPLIFICAÇÃO: Passa o objeto inteiro para o serviço
        if (widget.evento == null) {
          await _eventService.createEvent(
            eventoData,
            paroquiaId: _selectedParishId!,
            title: eventoData.titulo,
            descricao:
                eventoData.descricao ??
                '', // Provide a default empty string if null
            dateTime: eventoData.data_hora,
            local: eventoData.local,
            tempoLiturgico: eventoData.tempoLiturgico,
            solenidade: eventoData.solenidade,
          );
        } else {
          await _eventService.updateEvent(
            eventoData.id,
            paroquiaId: _selectedParishId!,
            title: eventoData.titulo,
            descricao:
                eventoData.descricao ??
                '', // Provide a default empty string if null
            dateTime: eventoData.data_hora,
            local: eventoData.local,
            tempoLiturgico: eventoData.tempoLiturgico,
            solenidade: eventoData.solenidade,
          );
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Evento salvo com sucesso!')),
          );
          context.pop();
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text('Erro ao salvar evento: $e')));
        }
      } finally {
        if (mounted) setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
      await _fetchLiturgicalData(picked);
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.evento == null ? 'Novo Evento' : 'Editar Evento'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(16.0),
                children: [
                  TextFormField(
                    controller: _titleController,
                    decoration: const InputDecoration(
                      labelText: 'Título do Evento',
                    ),
                    validator: (value) =>
                        value!.isEmpty ? 'Por favor, insira o título' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _descricaoController,
                    decoration: const InputDecoration(
                      labelText: 'Descrição (Opcional)',
                    ),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: _selectedParishId,
                    decoration: const InputDecoration(labelText: 'Paróquia'),
                    items: _parishes.map((parish) {
                      return DropdownMenuItem(
                        value: parish.id,
                        child: Text(parish.nome),
                      );
                    }).toList(),
                    onChanged: (value) =>
                        setState(() => _selectedParishId = value),
                    validator: (value) =>
                        value == null ? 'Selecione uma paróquia' : null,
                  ),
                  const SizedBox(height: 16),
                  ListTile(
                    title: Text(
                      _selectedDate == null
                          ? 'Selecionar Data'
                          : 'Data: ${DateFormat('dd/MM/yyyy').format(_selectedDate!)}',
                    ),
                    trailing: const Icon(Icons.calendar_today),
                    onTap: () => _selectDate(context),
                  ),
                  ListTile(
                    title: Text(
                      _selectedTime == null
                          ? 'Selecionar Hora'
                          : 'Hora: ${_selectedTime!.format(context)}',
                    ),
                    trailing: const Icon(Icons.access_time),
                    onTap: () => _selectTime(context),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _tempoLiturgicoController,
                    decoration: const InputDecoration(
                      labelText: 'Tempo Litúrgico',
                    ),
                    readOnly: true,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _solenidadeController,
                    decoration: const InputDecoration(labelText: 'Solenidade'),
                    readOnly: true,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _localController,
                    decoration: const InputDecoration(
                      labelText: 'Local (Opcional)',
                    ),
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _saveEvent,
                    child: Text(
                      widget.evento == null
                          ? 'Salvar Evento'
                          : 'Atualizar Evento',
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
