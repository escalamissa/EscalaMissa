import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:escala_missa/services/liturgical_calendar_service.dart';
import 'package:flutter/services.dart'; // For Clipboard

class LiturgyScreen extends StatefulWidget {
  const LiturgyScreen({super.key});

  @override
  State<LiturgyScreen> createState() => _LiturgyScreenState();
}

class _LiturgyScreenState extends State<LiturgyScreen> {
  final LiturgicalCalendarService _liturgicalCalendarService = LiturgicalCalendarService();
  DateTime _selectedDate = DateTime.now();
  Map<String, dynamic>? _liturgicalData;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _fetchLiturgyData();
  }

  Future<void> _fetchLiturgyData() async {
    setState(() {
      _isLoading = true;
    });
    try {
      _liturgicalData = await _liturgicalCalendarService.getLiturgicalData(_selectedDate);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar dados litúrgicos: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
      _fetchLiturgyData();
    }
  }

  void _copyToClipboard(String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Texto copiado para a área de transferência!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text('Liturgia Diária'),
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: () => _selectDate(context),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Data Selecionada: ${DateFormat('dd/MM/yyyy').format(_selectedDate)}',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 20),
                  if (_liturgicalData == null)
                    const Center(child: Text('Nenhum dado litúrgico encontrado para esta data.'))
                  else
                    _buildLiturgyDetails(),
                ],
              ),
            ),
    );
  }

  Widget _buildLiturgyDetails() {
    final liturgia = _liturgicalData!['liturgia']?.toString() ?? 'N/A';
    final solenidade = _liturgicalData!['solenidade'];
    final solenidadeNome = solenidade is Map ? solenidade['nome']?.toString() ?? 'N/A' : solenidade?.toString() ?? 'N/A';
    final cor = _liturgicalData!['cor']?.toString() ?? 'N/A';
    final leituras = _liturgicalData!['leituras'];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildDetailCard('Tempo Litúrgico', liturgia),
        _buildDetailCard('Solenidade', solenidadeNome),
        _buildColorCard('Cor Litúrgica', cor),
        if (leituras != null && leituras is Map)
          _buildLeituras(leituras as Map<String, dynamic>),
      ],
    );
  }

  Widget _buildDetailCard(String title, String content) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            Text(
              content,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildColorCard(String title, String colorName) {
    Color displayColor = Colors.grey; // Default color
    switch (colorName.toLowerCase()) {
      case 'verde':
        displayColor = Colors.green;
        break;
      case 'vermelho':
        displayColor = Colors.red;
        break;
      case 'branco':
        displayColor = Colors.white;
        break;
      case 'roxo':
        displayColor = Colors.purple;
        break;
      case 'rosa':
        displayColor = Colors.pink;
        break;
      case 'preto':
        displayColor = Colors.black;
        break;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(width: 10),
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                color: displayColor,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.grey.shade400),
              ),
            ),
            const SizedBox(width: 5),
            Text(
              colorName,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLeituras(Map<String, dynamic> leituras) {
    String allReadingsText = '';
    leituras.values.expand((leituraList) {
      if (leituraList is List) {
        return leituraList.map((leitura) {
          final titulo = leitura['referencia']?.toString() ?? 'Leitura';
          final texto = leitura['texto']?.toString() ?? '';
          allReadingsText += '${titulo}\n${texto}\n\n';
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                titulo,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontStyle: FontStyle.italic),
              ),
              const SizedBox(height: 2),
              Text(
                texto,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 10),
            ],
          );
        });
      }
      return [];
    }).toList();

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Leituras:',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                IconButton(
                  icon: const Icon(Icons.copy),
                  onPressed: () => _copyToClipboard(allReadingsText.trim()),
                ),
              ],
            ),
            const SizedBox(height: 5),
            ...leituras.values.expand((leituraList) {
              if (leituraList is List) {
                return leituraList.map((leitura) {
                  final titulo = leitura['referencia']?.toString() ?? 'Leitura';
                  final texto = leitura['texto']?.toString() ?? '';
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        titulo,
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontStyle: FontStyle.italic),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        texto,
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                      const SizedBox(height: 10),
                    ],
                  );
                });
              }
              return [];
            }).toList(),
          ],
        ),
      ),
    );
  }
}