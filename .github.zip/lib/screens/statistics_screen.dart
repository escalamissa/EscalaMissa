
import 'package:escala_missa/services/statistics_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class StatisticsScreen extends StatefulWidget {
  static const routeName = '/admin/statistics';
  const StatisticsScreen({super.key});

  @override
  State<StatisticsScreen> createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {
  final StatisticsService _statisticsService = StatisticsService();
  Map<String, int> _stats = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchStatistics();
  }

  Future<void> _fetchStatistics() async {
    setState(() {
      _isLoading = true;
    });
    try {
      final totalEvents = await _statisticsService.getTotalEvents();
      final totalScales = await _statisticsService.getTotalScales();
      final confirmedScales = await _statisticsService.getConfirmedScales();
      final totalUsers = await _statisticsService.getTotalUsers();
      final totalVolunteers = await _statisticsService.getTotalVolunteers();

      setState(() {
        _stats = {
          'totalEvents': totalEvents,
          'totalScales': totalScales,
          'confirmedScales': confirmedScales,
          'totalUsers': totalUsers,
          'totalVolunteers': totalVolunteers,
        };
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar estatísticas: $e')),
        );
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text('Estatísticas'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: ListView(
                children: [
                  _buildStatCard('Total de Eventos', _stats['totalEvents'] ?? 0),
                  _buildStatCard('Total de Escalas', _stats['totalScales'] ?? 0),
                  _buildStatCard('Escalas Confirmadas', _stats['confirmedScales'] ?? 0),
                  _buildStatCard('Total de Usuários', _stats['totalUsers'] ?? 0),
                  _buildStatCard('Total de Voluntários', _stats['totalVolunteers'] ?? 0),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _fetchStatistics,
        child: const Icon(Icons.refresh),
      ),
    );
  }

  Widget _buildStatCard(String title, int value) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        title: Text(title),
        trailing: Text(
          value.toString(),
          style: Theme.of(context).textTheme.headlineMedium,
        ),
      ),
    );
  }
}
