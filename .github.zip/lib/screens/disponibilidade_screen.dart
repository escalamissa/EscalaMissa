import 'package:escala_missa/services/disponibilidade_service.dart';
import 'package:escala_missa/services/pastoral_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:escala_missa/models/pastoral.dart';
import 'package:escala_missa/services/function_service.dart';
import 'package:intl/intl.dart';
import 'package:escala_missa/models/app_function.dart';
import 'package:escala_missa/models/disponibilidade.dart';

class DisponibilidadeScreen extends StatefulWidget {
  const DisponibilidadeScreen({super.key});

  @override
  State<DisponibilidadeScreen> createState() => _DisponibilidadeScreenState();
}

class _DisponibilidadeScreenState extends State<DisponibilidadeScreen> {
  // --- Serviços ---
  final DisponibilidadeService _disponibilidadeService =
      DisponibilidadeService();
  final PastoralService _pastoralService = PastoralService();
  final FunctionService _functionService = FunctionService();

  // --- Estado ---
  List<Pastoral> _pastorals = [];
  List<AppFunction> _functions = [];
  List<Disponibilidade> _disponibilidades = [];
  bool _isLoading = true;

  // --- Cores do Tema ---
  static const azulPrimario = Color(0xFF0050A0);
  static const textoPrincipal = Color(0xFF1C1C1C);
  static const textoSecundario = Color(0xFF5A5A5A);

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    setState(() => _isLoading = true);
    try {
      // Carrega dependências em paralelo com os dados principais
      final dependenciesFuture = _fetchDependencies();
      final disponibilidadesFuture = _disponibilidadeService
          .getDisponibilidades(
            userId: Supabase.instance.client.auth.currentUser!.id,
          );

      // Aguarda ambas as operações terminarem
      final responses = await Future.wait([
        dependenciesFuture,
        disponibilidadesFuture,
      ]);

      // A resposta de getDisponibilidades é uma List<Disponibilidade>
      final fetchedDisponibilidades = responses[1] as List<Disponibilidade>;

      setState(() {
        _disponibilidades = fetchedDisponibilidades;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Erro ao carregar dados: $e')));
      }
    }
    setState(() => _isLoading = false);
  }

  Future<dynamic> _fetchDependencies() async {
    try {
      _pastorals = await _pastoralService.getPastorais();
      final fetchedFunctions = await _functionService.getFunctions();
      _functions = fetchedFunctions
          .map((funcMap) => AppFunction.fromMap(funcMap))
          .toList();
    } catch (e) {
      // O erro já é tratado no _fetchData
      rethrow;
    }
  }

  Future<void> _deleteDisponibilidade(String id) async {
    setState(() => _isLoading = true);
    try {
      await _disponibilidadeService.deleteDisponibilidade(id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Disponibilidade removida com sucesso!'),
          ),
        );
        await _fetchData(); // Recarrega a lista
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao remover disponibilidade: $e')),
        );
      }
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text('Minhas Disponibilidades'),
        backgroundColor: azulPrimario,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: azulPrimario))
          : _buildAvailabilityList(),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddAvailabilitySheet(context),
        backgroundColor: azulPrimario,
        tooltip: 'Adicionar Disponibilidade',
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildAvailabilityList() {
    if (_disponibilidades.isEmpty) {
      return const Center(child: Text('Nenhuma disponibilidade registrada.'));
    }
    return RefreshIndicator(
      onRefresh: _fetchData,
      child: ListView.builder(
        padding: const EdgeInsets.only(
          top: 8.0,
          bottom: 80.0,
        ), // Padding para o FAB
        itemCount: _disponibilidades.length,
        itemBuilder: (context, index) {
          final disp = _disponibilidades[index];
          return _DisponibilidadeCard(
            disponibilidade: disp,
            onDelete: () => _deleteDisponibilidade(disp.id!),
          );
        },
      ),
    );
  }

  void _showAddAvailabilitySheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true, // Permite que o modal cresça
      builder: (ctx) {
        // Usa um StatefulWidget para gerenciar o estado do formulário dentro do modal
        return _AddDisponibilidadeForm(
          pastorals: _pastorals,
          functions: _functions,
          onAdd: (newDisp) async {
            setState(() => _isLoading = true);
            try {
              await _disponibilidadeService.createDisponibilidade(
                usuarioId: newDisp.usuarioId,
                pastoralId: newDisp.pastoralId,
                funcaoId: newDisp.funcaoId,
                dia: DateTime.parse(newDisp.dia),
                hora: newDisp.hora != null
                    ? TimeOfDay(
                        hour: int.parse(newDisp.hora!.split(':')[0]),
                        minute: int.parse(newDisp.hora!.split(':')[1]),
                      )
                    : null,
                observacao: newDisp.observacao,
              );
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Disponibilidade adicionada com sucesso!'),
                  ),
                );
                Navigator.of(ctx).pop(); // Fecha o modal
                await _fetchData(); // Recarrega a lista
              }
            } catch (e) {
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Erro ao adicionar disponibilidade: $e'),
                  ),
                );
              }
            } finally {
              if (mounted) setState(() => _isLoading = false);
            }
          },
        );
      },
    );
  }
}

// --- WIDGETS PERSONALIZADOS ---

class _DisponibilidadeCard extends StatelessWidget {
  final Disponibilidade disponibilidade;
  final VoidCallback onDelete;

  const _DisponibilidadeCard({
    required this.disponibilidade,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final DateTime dispDate = DateTime.parse(disponibilidade.dia);
    final TimeOfDay? dispTime = disponibilidade.hora != null
        ? TimeOfDay.fromDateTime(
            DateFormat('HH:mm:ss').parse(disponibilidade.hora!),
          )
        : null;

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      shape: RoundedRectangleBorder(
        side: BorderSide(color: Colors.grey.shade200),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            const Icon(
              Icons.event_available_outlined,
              color: _DisponibilidadeScreenState.azulPrimario,
              size: 32,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${DateFormat('dd/MM/yyyy').format(dispDate)} ${dispTime != null ? "- ${dispTime.format(context)}" : "(Dia inteiro)"}',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: _DisponibilidadeScreenState.textoPrincipal,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Pastoral: ${disponibilidade.pastoral?.nome ?? 'Qualquer uma'}',
                    style: const TextStyle(
                      fontSize: 14,
                      color: _DisponibilidadeScreenState.textoSecundario,
                    ),
                  ),
                  Text(
                    'Função: ${disponibilidade.funcao?.name ?? 'Qualquer uma'}',
                    style: const TextStyle(
                      fontSize: 14,
                      color: _DisponibilidadeScreenState.textoSecundario,
                    ),
                  ),
                ],
              ),
            ),
            IconButton(
              icon: Icon(Icons.delete_outline, color: Colors.red.shade400),
              tooltip: 'Remover',
              onPressed: onDelete,
            ),
          ],
        ),
      ),
    );
  }
}

class _AddDisponibilidadeForm extends StatefulWidget {
  final List<Pastoral> pastorals;
  final List<AppFunction> functions;
  final Function(Disponibilidade) onAdd;

  const _AddDisponibilidadeForm({
    required this.pastorals,
    required this.functions,
    required this.onAdd,
  });

  @override
  __AddDisponibilidadeFormState createState() =>
      __AddDisponibilidadeFormState();
}

class __AddDisponibilidadeFormState extends State<_AddDisponibilidadeForm> {
  String? _selectedPastoralId;
  String? _selectedFunctionId;
  DateTime _selectedDate = DateTime.now();
  TimeOfDay? _selectedTime;
  final _observacaoController = TextEditingController();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() => _selectedDate = picked);
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
    );
    if (picked != null && picked != _selectedTime) {
      setState(() => _selectedTime = picked);
    }
  }

  void _submit() {
    final newDisp = Disponibilidade(
      id: '', // ID será gerado pelo DB
      usuarioId: Supabase.instance.client.auth.currentUser!.id,
      dia: DateFormat('yyyy-MM-dd').format(_selectedDate),
      hora: _selectedTime != null
          ? '${_selectedTime!.hour.toString().padLeft(2, '0')}:${_selectedTime!.minute.toString().padLeft(2, '0')}:00'
          : null,
      pastoralId: _selectedPastoralId,
      funcaoId: _selectedFunctionId,
      observacao: _observacaoController.text.trim(),
    );
    widget.onAdd(newDisp);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 16,
        right: 16,
        top: 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Adicionar Nova Disponibilidade',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String?>(
              value: _selectedPastoralId,
              decoration: const InputDecoration(
                labelText: 'Pastoral (Opcional)',
              ),
              items: [
                const DropdownMenuItem<String?>(
                  value: null,
                  child: Text('Qualquer Pastoral'),
                ),
                ...widget.pastorals.map((pastoral) {
                  return DropdownMenuItem<String?>(
                    value: pastoral.id,
                    child: Text(pastoral.nome),
                  );
                }).toList(),
              ],
              onChanged: (value) => setState(() => _selectedPastoralId = value),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String?>(
              value: _selectedFunctionId,
              decoration: const InputDecoration(labelText: 'Função (Opcional)'),
              items: [
                const DropdownMenuItem<String?>(
                  value: null,
                  child: Text('Qualquer Função'),
                ),
                ...widget.functions.map((func) {
                  return DropdownMenuItem<String?>(
                    value: func.id,
                    child: Text(func.name),
                  );
                }).toList(),
              ],
              onChanged: (value) => setState(() => _selectedFunctionId = value),
            ),
            const SizedBox(height: 16),
            ListTile(
              title: Text(
                'Data: ${DateFormat('dd/MM/yyyy').format(_selectedDate)}',
              ),
              trailing: const Icon(Icons.calendar_today),
              onTap: () => _selectDate(context),
            ),
            ListTile(
              title: Text(
                _selectedTime == null
                    ? 'Selecionar Hora (Opcional)'
                    : 'Hora: ${_selectedTime!.format(context)}',
              ),
              trailing: const Icon(Icons.access_time),
              onTap: () => _selectTime(context),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _observacaoController,
              decoration: const InputDecoration(
                labelText: 'Observação (Opcional)',
              ),
              maxLines: 2,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _submit,
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                backgroundColor: _DisponibilidadeScreenState.azulPrimario,
              ),
              child: const Text('Adicionar Disponibilidade'),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
