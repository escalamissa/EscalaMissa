
import 'package:flutter/material.dart';
import 'package:escala_missa/screens/aviso_list_screen.dart';
import 'package:escala_missa/screens/escala_list_screen.dart';
import 'package:escala_missa/screens/event_list_screen.dart';
import 'package:escala_missa/screens/function_list_screen.dart';
import 'package:escala_missa/screens/parish_list_screen.dart';
import 'package:escala_missa/screens/pastoral_list_screen.dart';
import 'package:escala_missa/screens/statistics_screen.dart';
import 'package:escala_missa/screens/volunteer_history_screen.dart';
import 'package:go_router/go_router.dart';

class AdminPanelItem {
  final IconData icon;
  final String title;
  final String route;

  AdminPanelItem({required this.icon, required this.title, required this.route});
}

class AdminPanelScreen extends StatelessWidget {
  final List<AdminPanelItem> adminItems = [
    AdminPanelItem(icon: Icons.church, title: 'Paróquias', route: ParishListScreen.routeName),
    AdminPanelItem(icon: Icons.group, title: 'Pastorais', route: PastoralListScreen.routeName),
    AdminPanelItem(icon: Icons.work, title: 'Funções', route: FunctionListScreen.routeName),
    AdminPanelItem(icon: Icons.event, title: 'Eventos', route: EventListScreen.routeName),
    AdminPanelItem(icon: Icons.calendar_today, title: 'Escalas', route: EscalaListScreen.routeName),
    AdminPanelItem(icon: Icons.announcement, title: 'Avisos', route: AvisoListScreen.routeName),
    AdminPanelItem(icon: Icons.history, title: 'Histórico Voluntários', route: VolunteerHistoryScreen.routeName),
    AdminPanelItem(icon: Icons.bar_chart, title: 'Estatísticas', route: StatisticsScreen.routeName),
  ];

  AdminPanelScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text(
          'Painel Administrativo',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16.0),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16.0,
          mainAxisSpacing: 16.0,
          childAspectRatio: 1.0,
        ),
        itemCount: adminItems.length,
        itemBuilder: (context, index) {
          final item = adminItems[index];
          return GestureDetector(
            onTap: () {
              context.push(item.route);
            },
            child: Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.0),
              ),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Theme.of(context).primaryColor.withOpacity(0.8), Theme.of(context).primaryColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(15.0),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(item.icon, size: 48.0, color: Colors.white),
                    const SizedBox(height: 10.0),
                    Text(
                      item.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
