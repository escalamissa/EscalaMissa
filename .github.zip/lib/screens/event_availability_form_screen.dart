import 'package:escala_missa/models/event.dart';
import 'package:escala_missa/models/pastoral.dart';
import 'package:escala_missa/models/app_function.dart';
import 'package:escala_missa/services/disponibilidade_service.dart';
import 'package:escala_missa/services/pastoral_service.dart';
import 'package:escala_missa/services/function_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';

class EventAvailabilityFormScreen extends StatefulWidget {
  final Evento event;

  const EventAvailabilityFormScreen({super.key, required this.event});

  @override
  State<EventAvailabilityFormScreen> createState() => _EventAvailabilityFormScreenState();
}

class _EventAvailabilityFormScreenState extends State<EventAvailabilityFormScreen> {
  final _formKey = GlobalKey<FormState>();
  String? _selectedPastoralId;
  String? _selectedFunctionId;
  final _observacaoController = TextEditingController();

  final DisponibilidadeService _disponibilidadeService = DisponibilidadeService();
  final PastoralService _pastoralService = PastoralService();
  final FunctionService _functionService = FunctionService();

  List<Pastoral> _pastorals = [];
  List<AppFunction> _functions = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchDependencies();
  }

  Future<void> _fetchDependencies() async {
    setState(() {
      _isLoading = true;
    });
    try {
      _pastorals = await _pastoralService.getPastorais();
      final fetchedFunctions = await _functionService.getFunctions();
      _functions = fetchedFunctions
          .map((funcMap) => AppFunction.fromMap(funcMap))
          .toList();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar dependências: $e')),
        );
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _saveAvailability() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      try {
        await _disponibilidadeService.createDisponibilidade(
          usuarioId: Supabase.instance.client.auth.currentUser!.id,
          pastoralId: _selectedPastoralId,
          funcaoId: _selectedFunctionId,
          dia: DateTime.parse(widget.event.data_hora),
          hora: widget.event.data_hora.isNotEmpty
              ? TimeOfDay.fromDateTime(DateTime.parse(widget.event.data_hora))
              : null,
          observacao: _observacaoController.text.trim(),
        );
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Disponibilidade salva com sucesso!')),
          );
          context.pop(); // Go back after saving
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Erro ao salvar disponibilidade: $e')),
          );
        }
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  @override
  void dispose() {
    _observacaoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Marcar Disponibilidade'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(16.0),
                children: [
                  Text(
                    'Evento: ${widget.event.titulo}',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Data: ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.parse(widget.event.data_hora))}',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String?>(
                    value: _selectedPastoralId,
                    decoration: const InputDecoration(labelText: 'Pastoral (Opcional)'),
                    items: [
                      const DropdownMenuItem<String?>(
                        value: null,
                        child: Text('Qualquer Pastoral'),
                      ),
                      ..._pastorals.map((pastoral) {
                        return DropdownMenuItem<String?>(
                          value: pastoral.id,
                          child: Text(pastoral.nome),
                        );
                      }).toList(),
                    ],
                    onChanged: (value) => setState(() => _selectedPastoralId = value),
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String?>(
                    value: _selectedFunctionId,
                    decoration: const InputDecoration(labelText: 'Função (Opcional)'),
                    items: [
                      const DropdownMenuItem<String?>(
                        value: null,
                        child: Text('Qualquer Função'),
                      ),
                      ..._functions.map((func) {
                        return DropdownMenuItem<String?>(
                          value: func.id,
                          child: Text(func.name),
                        );
                      }).toList(),
                    ],
                    onChanged: (value) => setState(() => _selectedFunctionId = value),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _observacaoController,
                    decoration: const InputDecoration(
                      labelText: 'Observação (Opcional)',
                    ),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _saveAvailability,
                    child: const Text('Salvar Disponibilidade'),
                  ),
                ],
              ),
            ),
    );
  }
}
