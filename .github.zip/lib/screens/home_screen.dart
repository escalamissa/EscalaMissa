import 'package:escala_missa/services/escala_service.dart';
import 'package:escala_missa/services/function_service.dart';
import 'package:escala_missa/services/pastoral_service.dart';
import 'package:escala_missa/services/profile_service.dart';
import 'package:escala_missa/models/user_profile.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:escala_missa/models/pastoral.dart';
import 'package:escala_missa/models/app_function.dart';
import 'package:escala_missa/models/escala.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:showcaseview/showcaseview.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // --- Serviços ---
  final ProfileService _profileService = ProfileService();
  final PastoralService _pastoralService = PastoralService();
  late EscalaService _escalaService; // Modified to be late and non-final
  final FunctionService _functionService = FunctionService();

  // --- Global Keys para o Showcase ---
  final GlobalKey _calendarKey = GlobalKey();
  final GlobalKey _myAgendaKey = GlobalKey();
  final GlobalKey _selectEventKey = GlobalKey();
  final GlobalKey _notificationsKey = GlobalKey();

  // --- Estado ---
  UserProfile? _userProfile;
  List<Pastoral> _pastorals = [];
  List<AppFunction> _functions = [];
  List<Escala> _selectedDayScales = [];
  Map<DateTime, List<Escala>> _scalesByDay = {};
  String? _selectedPastoralFilter;
  String? _selectedFunctionFilter;

  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  CalendarFormat _calendarFormat = CalendarFormat.month;

  bool _isLoading = true;

  // --- Cores do tema ---
  static const azulSereno = Color(0xFFF0F4FF);
  static const azulPrimario = Color(0xFF0050A0);
  static const textoPrincipal = Color(0xFF1C1C1C);
  static const textoSecundario = Color(0xFF5A5A5A);
  static const douradoDivino = Color(0xFFFFC107);
  static const cinzaSuave = Color(0xFFF5F5F5);

  @override
  void initState() {
    super.initState();
    _escalaService = EscalaService(); // Initialized in initState
    // CORREÇÃO: Usa UTC para o dia selecionado inicial para consistência
    final now = DateTime.now();
    _selectedDay = DateTime.utc(now.year, now.month, now.day);
    _fetchData().then((_) {
      _checkAndStartTour();
    });
  }

  Future<void> _checkAndStartTour() async {
    final prefs = await SharedPreferences.getInstance();
    final showTour = prefs.getBool('showHomeTour') ?? true;

    if (showTour) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        ShowCaseWidget.of(context).startShowCase([
          _calendarKey,
          _myAgendaKey,
          _selectEventKey,
          _notificationsKey,
        ]);
      });
      await prefs.setBool('showHomeTour', false);
    }
  }

  Future<void> _fetchData() async {
    setState(() => _isLoading = true);
    try {
      _userProfile = await _profileService.getProfile();
      _pastorals = await _pastoralService.getPastorais();
      final fetchedFunctions = await _functionService.getFunctions();
      _functions = fetchedFunctions
          .map((funcMap) => AppFunction.fromMap(funcMap))
          .toList();
      await _fetchAllScalesAndGroup();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Erro ao carregar dados: $e')));
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _fetchAllScalesAndGroup() async {
    try {
      final allScales = await _escalaService.getEscalas();
      _scalesByDay.clear();

      final filteredScales = allScales.where((escala) {
        if (_userProfile?.perfil == 'admin' ||
            _userProfile?.perfil == 'coordenador' ||
            _userProfile?.perfil == 'padre') {
          return true;
        } else if (_userProfile?.perfil == 'voluntario') {
          return escala.voluntario?.id == _userProfile?.id ||
              escala.voluntario == null;
        }
        return false;
      }).toList();

      for (var escala in filteredScales) {
        final eventDateTime = DateTime.tryParse(escala.evento?.data_hora ?? '');
        if (eventDateTime != null) {
          // CORREÇÃO: Usa UTC para criar a chave do mapa
          final day = DateTime.utc(
            eventDateTime.year,
            eventDateTime.month,
            eventDateTime.day,
          );
          _scalesByDay.putIfAbsent(day, () => []).add(escala);
        }
      }
      _updateSelectedDayScales();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Erro ao carregar escalas: $e')));
      }
    }
  }

  void _updateSelectedDayScales() {
    _selectedDayScales =
        _scalesByDay[_selectedDay]?.where((escala) {
          bool matchesPastoral =
              _selectedPastoralFilter == null ||
              escala.pastoral?.id == _selectedPastoralFilter;
          bool matchesFunction =
              _selectedFunctionFilter == null ||
              escala.funcao?.id == _selectedFunctionFilter;
          return matchesPastoral && matchesFunction;
        }).toList() ??
        [];
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    // CORREÇÃO: Normaliza o dia selecionado para UTC antes de comparar e atualizar o estado
    final normalizedSelectedDay = DateTime.utc(
      selectedDay.year,
      selectedDay.month,
      selectedDay.day,
    );

    if (!isSameDay(_selectedDay, normalizedSelectedDay)) {
      setState(() {
        _selectedDay = normalizedSelectedDay;
        _focusedDay = focusedDay; // focusedDay pode continuar local
        _updateSelectedDayScales();
      });
    }
  }

  Future<void> _signOut() async {
    try {
      await Supabase.instance.client.auth.signOut();
      if (mounted) context.go('/login');
    } catch (e) {
      // Handle error
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: azulSereno,
      appBar: AppBar(
        title: const Text(
          'Escala Missa',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: azulPrimario,
        elevation: 2,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sair',
            onPressed: _signOut,
          ),
          IconButton(
            icon: const Icon(Icons.book),
            tooltip: 'Liturgia Diária',
            onPressed: () => context.push('/liturgy'),
          ),
          Showcase(
            key: _notificationsKey,
            description: 'Aqui você verá os avisos e notificações.',
            child: IconButton(
              icon: const Icon(Icons.notifications),
              tooltip: 'Avisos',
              onPressed: () => context.push('/avisos'),
            ),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: azulPrimario))
          : RefreshIndicator(
              onRefresh: _fetchData,
              child: ListView(
                padding: const EdgeInsets.all(16.0),
                children: [
                  _buildHeader(context),
                  const SizedBox(height: 24),
                  _buildActionGrid(context),
                  const SizedBox(height: 24),
                  Showcase(
                    key: _calendarKey,
                    description: 'Selecione um dia para ver as escalas.',
                    child: _buildCalendar(context),
                  ),
                  const SizedBox(height: 24),
                  _buildScaleList(context),
                ],
              ),
            ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Bem-vindo(a), ${_userProfile?.nome ?? 'Usuário'}!',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            color: textoPrincipal,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Perfil: ${_userProfile?.perfil ?? 'Não definido'}',
          style: Theme.of(
            context,
          ).textTheme.titleMedium?.copyWith(color: textoSecundario),
        ),
      ],
    );
  }

  Widget _buildActionGrid(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: 2.5,
      children: [
        if (_userProfile?.perfil == 'admin')
          _ActionCard(
            title: 'Painel Admin',
            icon: Icons.dashboard_customize,
            onTap: () => context.push('/admin'),
          ),
        if (_userProfile?.perfil == 'admin')
          _ActionCard(
            title: 'Funções',
            icon: Icons.work,
            onTap: () => context.push('/admin/functions'),
          ),
        if (_userProfile?.perfil == 'voluntario')
          _ActionCard(
            title: 'Disponibilidade',
            icon: Icons.event_available,
            onTap: () => context.push('/disponibilidades'),
          ),
        Showcase(
          key: _myAgendaKey,
          description: 'Acesse sua agenda pessoal aqui.',
          child: _ActionCard(
            title: 'Minha Agenda',
            icon: Icons.calendar_today,
            onTap: () => context.push('/agenda'),
          ),
        ),
        Showcase(
          key: _selectEventKey,
          description: 'Selecione um evento para marcar sua disponibilidade.',
          child: _ActionCard(
            title: 'Selecionar Evento',
            icon: Icons.event,
            onTap: () => context.push('/event_selection'),
          ),
        ),
        _ActionCard(
          title: 'Mural de Avisos',
          icon: Icons.campaign,
          onTap: () => context.push('/avisos'),
        ),
        if (_userProfile?.perfil == 'voluntario')
          _ActionCard(
            title: 'Meu Histórico',
            icon: Icons.history,
            onTap: () => context.push('/history'),
          ),
      ],
    );
  }

  Widget _buildCalendar(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: TableCalendar(
        firstDay: DateTime.utc(2020),
        lastDay: DateTime.utc(2030),
        focusedDay: _focusedDay,
        selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
        calendarFormat: _calendarFormat,
        locale: 'pt_BR',
        onDaySelected: _onDaySelected,
        onFormatChanged: (format) {
          if (_calendarFormat != format) {
            setState(() => _calendarFormat = format);
          }
        },
        onPageChanged: (focusedDay) {
          setState(() => _focusedDay = focusedDay);
        },
        headerStyle: const HeaderStyle(
          formatButtonVisible: false,
          titleCentered: true,
          titleTextStyle: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: azulPrimario,
          ),
        ),
        calendarStyle: CalendarStyle(
          todayDecoration: BoxDecoration(
            color: douradoDivino.withOpacity(0.5),
            shape: BoxShape.circle,
          ),
          selectedDecoration: const BoxDecoration(
            color: azulPrimario,
            shape: BoxShape.circle,
          ),
          defaultTextStyle: const TextStyle(color: textoPrincipal),
          weekendTextStyle: TextStyle(color: azulPrimario.withOpacity(0.8)),
        ),
        eventLoader: (day) {
          // CORREÇÃO: Usa UTC para buscar os eventos no mapa
          final normalizedDay = DateTime.utc(day.year, day.month, day.day);
          return _scalesByDay[normalizedDay] ?? [];
        },
      ),
    );
  }

  Widget _buildScaleList(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Escalas para ${DateFormat('dd/MM/yyyy', 'pt_BR').format(_selectedDay!)}',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            color: textoPrincipal,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 16),
        if (_selectedDayScales.isNotEmpty)
          Row(
            children: [
              Expanded(
                child: _buildFilterDropdown(
                  _pastorals,
                  _selectedPastoralFilter,
                  'Filtrar por Pastoral',
                  (value) {
                    setState(() {
                      _selectedPastoralFilter = value;
                      _updateSelectedDayScales();
                    });
                  },
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildFilterDropdown(
                  _functions,
                  _selectedFunctionFilter,
                  'Filtrar por Função',
                  (value) {
                    setState(() {
                      _selectedFunctionFilter = value;
                      _updateSelectedDayScales();
                    });
                  },
                ),
              ),
            ],
          ),
        const SizedBox(height: 16),
        if (_selectedDayScales.isEmpty)
          const Center(
            child: Padding(
              padding: EdgeInsets.all(20.0),
              child: Text(
                'Nenhuma escala encontrada para este dia.',
                style: TextStyle(fontSize: 16, color: textoSecundario),
              ),
            ),
          )
        else
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _selectedDayScales.length,
            itemBuilder: (context, index) {
              final escala = _selectedDayScales[index];
              return _EscalaCard(
                escala: escala,
                onTap: () {
                  final userPerfil = _userProfile?.perfil;
                  if (userPerfil == 'admin' ||
                      userPerfil == 'coordenador' ||
                      userPerfil == 'padre') {
                    context.push('/admin/escalas/edit', extra: escala);
                  } else if (userPerfil == 'voluntario') {
                    context.push('/escala_confirmation', extra: escala);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Ação não permitida para o seu perfil.'),
                      ),
                    );
                  }
                },              );
            },
          ),
      ],
    );
  }

  Widget _buildFilterDropdown(
    List<dynamic> items,
    String? currentValue,
    String label,
    ValueChanged<String?> onChanged,
  ) {
    return DropdownButtonFormField<String?>(
      isExpanded: true,
      value: currentValue,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      ),
      items: [
        const DropdownMenuItem<String?>(value: null, child: Text('Todas')),
        ...items.map<DropdownMenuItem<String?>>((item) {
          String id;
          String name;
          if (item is Pastoral) {
            id = item.id;
            name = item.nome;
          } else if (item is AppFunction) {
            id = item.id;
            name = item.name;
          } else {
            id = '';
            name = 'Item inválido';
          }
          return DropdownMenuItem<String?>(value: id, child: Text(name));
        }).toList(),
      ],
      onChanged: onChanged,
    );
  }
}

class _ActionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;

  const _ActionCard({
    required this.title,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      color: _HomeScreenState.cinzaSuave,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: _HomeScreenState.azulPrimario),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  color: _HomeScreenState.textoPrincipal,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EscalaCard extends StatelessWidget {
  final Escala escala;
  final VoidCallback? onTap;

  const _EscalaCard({required this.escala, this.onTap});

  Color _getStatusColor(String? status) {
    switch (status) {
      case 'confirmado':
        return Colors.green.shade700;
      case 'pendente':
        return Colors.orange.shade800;
      case 'cancelado':
        return Colors.red.shade700;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final DateTime? eventDateTime = DateTime.tryParse(
      escala.evento?.data_hora ?? '',
    );

    if (eventDateTime == null) {
      return const Card(
        child: ListTile(title: Text('Data do evento inválida')),
      );
    }

    final voluntarioNome = escala.voluntario?.nome ?? 'Vaga aberta';
    final status = escala.status;

    return Card(
      elevation: 2,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        side: BorderSide(color: Colors.grey.shade200),
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Column(
                children: [
                  Text(
                    DateFormat('HH').format(eventDateTime),
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: _HomeScreenState.azulPrimario,
                    ),
                  ),
                  Text(
                    DateFormat('mm').format(eventDateTime),
                    style: const TextStyle(
                      fontSize: 16,
                      color: _HomeScreenState.textoSecundario,
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${escala.evento?.titulo ?? 'Evento'} - ${escala.funcao?.name ?? 'Função'}',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: _HomeScreenState.textoPrincipal,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Pastoral: ${escala.pastoral?.nome ?? 'N/A'}',
                      style: const TextStyle(
                        fontSize: 14,
                        color: _HomeScreenState.textoSecundario,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(
                          Icons.person,
                          size: 16,
                          color: _HomeScreenState.textoSecundario,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          voluntarioNome,
                          style: const TextStyle(
                            fontSize: 14,
                            fontStyle: FontStyle.italic,
                            color: _HomeScreenState.textoSecundario,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Chip(
                label: Text(
                  status.isNotEmpty
                      ? status.substring(0, 1).toUpperCase() +
                            status.substring(1)
                      : '',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                backgroundColor: _getStatusColor(status),
                padding: const EdgeInsets.symmetric(horizontal: 8),
              ),
            ],
          ),
        ),
      ),
    );
  }
}