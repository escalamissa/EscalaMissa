
import 'package:escala_missa/services/parish_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:escala_missa/models/parish.dart'; // Added import

class ParishListScreen extends StatefulWidget {
  static const routeName = '/admin/parishes';
  const ParishListScreen({super.key});

  @override
  State<ParishListScreen> createState() => _ParishListScreenState();
}

class _ParishListScreenState extends State<ParishListScreen> {
  final ParishService _parishService = ParishService();
  List<Parish> _parishes = []; // Changed to List<Parish>
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchParishes();
  }

  Future<void> _fetchParishes() async {
    setState(() {
      _isLoading = true;
    });
    try {
      final parishes = await _parishService.getParishes();
      setState(() {
        _parishes = parishes;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar paróquias: $e')),
        );
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text('Gerenciar Paróquias'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => context.push('/admin/parishes/new'),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _parishes.isEmpty
              ? const Center(child: Text('Nenhuma paróquia cadastrada.'))
              : ListView.builder(
                  itemCount: _parishes.length,
                  itemBuilder: (context, index) {
                    final parish = _parishes[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      child: ListTile(
                        title: Text(parish.nome),
                        subtitle: Text('${parish.cidade ?? ''} - ${parish.uf ?? ''}'),
                        // onTap: () => context.go('/admin/parishes/${parish.id}'), // For editing
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _fetchParishes,
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
