import 'package:escala_missa/services/function_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class FunctionListScreen extends StatefulWidget {
  static const routeName = '/admin/functions';
  const FunctionListScreen({super.key});

  @override
  State<FunctionListScreen> createState() => _FunctionListScreenState();
}

class _FunctionListScreenState extends State<FunctionListScreen> {
  final FunctionService _functionService = FunctionService();
  List<Map<String, dynamic>> _functions = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchFunctions();
  }

  Future<void> _fetchFunctions() async {
    setState(() {
      _isLoading = true;
    });
    try {
      final functions = await _functionService.getFunctions();
      setState(() {
        _functions = functions;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Erro ao carregar funções: $e')));
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _deleteFunction(String id) async {
    final bool? confirm = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirmar Exclusão'),
          content: const Text('Tem certeza que deseja excluir esta função?'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancelar'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Excluir'),
            ),
          ],
        );
      },
    );

    if (confirm == true) {
      setState(() {
        _isLoading = true;
      });
      try {
        await _functionService.deleteFunction(id);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Função excluída com sucesso!')),
          );
          _fetchFunctions(); // Refresh list
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text('Erro ao excluir função: $e')));
        }
      }
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text('Gerenciar Funções'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => context.push('/admin/functions/new'),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _functions.isEmpty
          ? const Center(child: Text('Nenhuma função cadastrada.'))
          : ListView.builder(
              itemCount: _functions.length,
              itemBuilder: (context, index) {
                final function = _functions[index];
                return Card(
                  margin: const EdgeInsets.symmetric(
                    vertical: 8,
                    horizontal: 16,
                  ),
                  child: ListTile(
                    title: Text(function['nome'] ?? ''),
                    subtitle: Text(function['descricao'] ?? ''),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () => context.push(
                            '/admin/functions/edit',
                            extra: function,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _deleteFunction(function['id']),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _fetchFunctions,
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
