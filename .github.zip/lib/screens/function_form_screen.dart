
import 'package:escala_missa/models/app_function.dart';
import 'package:escala_missa/services/function_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class FunctionFormScreen extends StatefulWidget {
  final AppFunction? function;
  const FunctionFormScreen({super.key, this.function});

  @override
  State<FunctionFormScreen> createState() => _FunctionFormScreenState();
}

class _FunctionFormScreenState extends State<FunctionFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final FunctionService _functionService = FunctionService();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.function != null) {
      _nameController.text = widget.function!.name;
      _descriptionController.text = widget.function!.description;
    }
  }

  Future<void> _saveFunction() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      try {
        if (widget.function == null) {
          // Create new function
          await _functionService.createFunction(
            nome: _nameController.text.trim(),
            descricao: _descriptionController.text.trim(),
          );
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Função salva com sucesso!')),
            );
            context.pop(); // Go back to list after saving
            context.go('/admin/functions'); // Go back to list after saving
          }
        } else {
          // Update existing function
          await _functionService.updateFunction(
            id: widget.function!.id,
            nome: _nameController.text.trim(),
            descricao: _descriptionController.text.trim(),
          );
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Função atualizada com sucesso!')),
            );
            context.pop(); // Go back to list after saving
          }
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Erro ao salvar função: $e')),
          );
        }
      }
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.function == null ? 'Nova Função' : 'Editar Função'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(16.0),
                children: [
                  TextFormField(
                    controller: _nameController,
                    decoration: const InputDecoration(labelText: 'Nome da Função'),
                    validator: (value) =>
                        value!.isEmpty ? 'Por favor, insira o nome da função' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _descriptionController,
                    decoration: const InputDecoration(labelText: 'Descrição (Opcional)'),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _saveFunction,
                    child: const Text('Salvar Função'),
                  ),
                ],
              ),
            ),
    );
  }
}
