import 'package:escala_missa/models/escala.dart';
import 'package:escala_missa/services/escala_service.dart';
import 'package:escala_missa/services/pdf_service.dart';
import 'package:escala_missa/services/profile_service.dart';
import 'package:escala_missa/models/user_profile.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import 'package:escala_missa/services/notification_service.dart'; // Added import

class EscalaListScreen extends StatefulWidget {
  static const routeName = '/admin/escalas';
  final NotificationService notificationService; // Added
  const EscalaListScreen({super.key, required this.notificationService}); // Modified

  @override
  State<EscalaListScreen> createState() => _EscalaListScreenState();
}

class _EscalaListScreenState extends State<EscalaListScreen> {
  late EscalaService _escalaService; // Modified to be late and non-final
  final ProfileService _profileService = ProfileService();
  final PdfService _pdfService = PdfService();
  List<Escala> _escalas = [];
  UserProfile? _userProfile;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _escalaService = EscalaService(); // Initialized in initState
    _fetchData();
  }

  Future<void> _fetchData() async {
    setState(() {
      _isLoading = true;
    });
    try {
      _userProfile = await _profileService.getProfile();
      final escalas = await _escalaService.getEscalas();
      setState(() {
        _escalas = escalas;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Erro ao carregar dados: $e')));
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _approveEscala(String escalaId) async {
    setState(() {
      _isLoading = true;
    });
    try {
      await _escalaService.updateEscalaStatus(
        id: escalaId,
        status: 'confirmado',
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Escala aprovada com sucesso!')),
        );
        _fetchData(); // Refresh list
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Erro ao aprovar escala: $e')));
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  bool _canApprove(Escala escala) {
    final userPerfil = _userProfile?.perfil;
    if (userPerfil == 'admin' || userPerfil == 'padre') {
      return true; // Admin and Padre can approve any scale
    }
    if (userPerfil == 'coordenador') {
      // Coordenador can approve scales in their own pastoral
      // This requires fetching the pastoral_id from the user profile, which is not directly available in _userProfile yet.
      // For now, we'll assume a coordinator can approve any scale if they are a coordinator.
      return true; // Simplified for now
    }
    return false;
  }

  bool _canExport() {
    final userPerfil = _userProfile?.perfil;
    return userPerfil == 'admin' ||
        userPerfil == 'padre' ||
        userPerfil == 'coordenador';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text('Gerenciar Escalas'),
        actions: [
          if (_canExport())
            IconButton(
              icon: const Icon(Icons.picture_as_pdf),
              onPressed: () => _pdfService.generateEscalasPdf(
                _escalas.map((e) => e.toMap()).toList(),
              ),
            ),
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => context.push('/admin/escalas/new'),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _escalas.isEmpty
          ? const Center(child: Text('Nenhuma escala cadastrada.'))
          : ListView.builder(
              itemCount: _escalas.length,
              itemBuilder: (context, index) {
                final escala = _escalas[index];
                final DateTime eventDateTime = DateTime.parse(
                  escala.evento?.data_hora ?? '',
                );
                final bool isPending = escala.status == 'pendente';
                final bool showApproveButton = isPending && _canApprove(escala);

                return Card(
                  margin: const EdgeInsets.symmetric(
                    vertical: 8,
                    horizontal: 16,
                  ),
                  child: ListTile(
                    title: Text(
                      '${escala.evento?.titulo ?? 'Evento'} - ${escala.funcao?.name ?? 'Função'}',
                    ),
                    subtitle: Text(
                      '${escala.voluntario?.nome ?? 'Voluntário'} (${escala.pastoral?.nome ?? 'Pastoral'}) -                            ${DateFormat('dd/MM/yyyy HH:mm').format(eventDateTime)}',
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(escala.status),
                        if (showApproveButton)
                          IconButton(
                            icon: const Icon(
                              Icons.check_circle,
                              color: Colors.green,
                            ),
                            onPressed: () => _approveEscala(escala.id!),
                          ),
                      ],
                    ),
                    onTap: () => context.push(
                      '/admin/escalas/edit',
                      extra: escala,
                    ), // For editing
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _fetchData,
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
