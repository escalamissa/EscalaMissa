import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/app_user.dart';
import '../models/paroquia.dart';
import '../services/database_service.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nomeController = TextEditingController();
  final _telefoneController = TextEditingController();
  final _dbService = DatabaseService();

  Perfil? _selectedPerfil = Perfil.fiel;
  Paroquia? _selectedParoquia;
  List<Paroquia> _paroquias = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }

  Future<void> _loadInitialData() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user != null) {
      final appUser = await _dbService.getAppUser(user.id);
      if (appUser != null) {
        _nomeController.text = appUser.nome;
        _telefoneController.text = appUser.telefone ?? '';
        _selectedPerfil = appUser.perfil;
      }
    }
    _paroquias = await _dbService.getParoquias();
    if (_paroquias.isNotEmpty && _selectedParoquia == null) {
        // Try to pre-select a parish if the user already has one
        final userParoquiaId = (await _dbService.getAppUser(user!.id))?.paroquiaId;
        if (userParoquiaId != null) {
            _selectedParoquia = _paroquias.firstWhere((p) => p.id == userParoquiaId, orElse: () => _paroquias.first);
        } else {
            _selectedParoquia = _paroquias.first;
        }
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _saveProfile() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      final user = Supabase.instance.client.auth.currentUser;
      if (user != null) {
        final updatedUser = AppUser(
          id: user.id,
          nome: _nomeController.text,
          telefone: _telefoneController.text,
          perfil: _selectedPerfil!,
          paroquiaId: _selectedParoquia!.id,
        );
        await _dbService.updateUserProfile(updatedUser);
      }

      setState(() {
        _isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Perfil atualizado com sucesso!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Editar Perfil'),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    TextFormField(
                      controller: _nomeController,
                      decoration: InputDecoration(labelText: 'Nome'),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Por favor, insira seu nome';
                        }
                        return null;
                      },
                    ),
                    TextFormField(
                      controller: _telefoneController,
                      decoration: InputDecoration(labelText: 'Telefone'),
                    ),
                    DropdownButtonFormField<Perfil>(
                      value: _selectedPerfil,
                      decoration: InputDecoration(labelText: 'Perfil'),
                      items: [Perfil.voluntario, Perfil.fiel].map((Perfil perfil) {
                        return DropdownMenuItem<Perfil>(
                          value: perfil,
                          child: Text(perfil.toString().split('.').last),
                        );
                      }).toList(),
                      onChanged: (Perfil? newValue) {
                        setState(() {
                          _selectedPerfil = newValue;
                        });
                      },
                    ),
                    DropdownButtonFormField<Paroquia>(
                      value: _selectedParoquia,
                      decoration: InputDecoration(labelText: 'Paróquia'),
                      items: _paroquias.map((Paroquia paroquia) {
                        return DropdownMenuItem<Paroquia>(
                          value: paroquia,
                          child: Text(paroquia.nome),
                        );
                      }).toList(),
                      onChanged: (Paroquia? newValue) {
                        setState(() {
                          _selectedParoquia = newValue;
                        });
                      },
                      validator: (value) =>
                          value == null ? 'Campo obrigatório' : null,
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: _saveProfile,
                      child: Text('Salvar'),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
