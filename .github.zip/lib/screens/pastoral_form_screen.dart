import 'package:escala_missa/models/parish.dart';
import 'package:escala_missa/models/pastoral.dart';
import 'package:escala_missa/models/user_profile.dart';
import 'package:escala_missa/services/parish_service.dart';
import 'package:escala_missa/services/pastoral_service.dart';
import 'package:escala_missa/services/profile_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class PastoralFormScreen extends StatefulWidget {
  final Pastoral? pastoral; // Pastoral opcional para edição
  const PastoralFormScreen({super.key, this.pastoral});

  @override
  State<PastoralFormScreen> createState() => _PastoralFormScreenState();
}

class _PastoralFormScreenState extends State<PastoralFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nomeController;
  String? _selectedParishId;
  String? _selectedCoordinatorId;

  final PastoralService _pastoralService = PastoralService();
  final ParishService _parishService = ParishService();
  final ProfileService _profileService = ProfileService();

  List<Parish> _parishes = [];
  List<UserProfile> _coordinators = [];
  bool _isLoading = true;

  // --- Cores do Tema ---
  static const azulPrimario = Color(0xFF0050A0);

  @override
  void initState() {
    super.initState();
    _nomeController = TextEditingController(text: widget.pastoral?.nome ?? '');
    if (widget.pastoral != null) {
      _selectedParishId = widget.pastoral!.paroquiaId;
      _selectedCoordinatorId = widget.pastoral!.coordenadorId;
    }
    _fetchDependencies();
  }

  Future<void> _fetchDependencies() async {
    setState(() => _isLoading = true);
    try {
      _parishes = await _parishService.getParishes();
      // Busca usuários que podem ser coordenadores (ex: 'admin', 'padre', 'coordenador')
      _coordinators = await _profileService.getProfilesByRoles([
        'admin',
        'padre',
        'coordenador',
      ]);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar dependências: $e')),
        );
      }
    }
    setState(() => _isLoading = false);
  }

  Future<void> _savePastoral() async {
    if (_formKey.currentState!.validate()) {
      if (_selectedParishId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Por favor, selecione uma paróquia.')),
        );
        return;
      }

      setState(() => _isLoading = true);
      try {
        // Cria um objeto Pastoral com os dados do formulário
        final pastoralData = Pastoral(
          id: widget.pastoral?.id ?? '', // ID vazio para criação
          nome: _nomeController.text.trim(),
          paroquiaId: _selectedParishId!,
          coordenadorId: _selectedCoordinatorId,
          ativa:
              widget.pastoral?.ativa ??
              true, // Mantém o status ou assume como ativo
        );

        if (widget.pastoral == null) {
          // Cria uma nova pastoral
          await _pastoralService.createPastoral(pastoralData);
        } else {
          // Atualiza uma pastoral existente
          await _pastoralService.updatePastoral(pastoralData);
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Pastoral salva com sucesso!')),
          );
          context.pop(); // Volta para a lista
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Erro ao salvar pastoral: $e')),
          );
        }
      } finally {
        if (mounted) setState(() => _isLoading = false);
      }
    }
  }

  @override
  void dispose() {
    _nomeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.pastoral == null ? 'Nova Pastoral' : 'Editar Pastoral',
        ),
        backgroundColor: azulPrimario,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(16.0),
                children: [
                  TextFormField(
                    controller: _nomeController,
                    decoration: const InputDecoration(
                      labelText: 'Nome da Pastoral',
                    ),
                    validator: (value) => value!.isEmpty
                        ? 'Por favor, insira o nome da pastoral'
                        : null,
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: _selectedParishId,
                    decoration: const InputDecoration(labelText: 'Paróquia'),
                    items: _parishes.map((parish) {
                      return DropdownMenuItem(
                        value: parish.id,
                        child: Text(parish.nome),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() => _selectedParishId = value);
                    },
                    validator: (value) =>
                        value == null ? 'Selecione uma paróquia' : null,
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String?>(
                    value: _selectedCoordinatorId,
                    decoration: const InputDecoration(
                      labelText: 'Coordenador (Opcional)',
                    ),
                    items: [
                      const DropdownMenuItem<String?>(
                        value: null,
                        child: Text('Nenhum'),
                      ),
                      ..._coordinators.map((user) {
                        return DropdownMenuItem<String?>(
                          value: user.id,
                          child: Text(user.nome),
                        );
                      }),
                    ],
                    onChanged: (value) {
                      setState(() => _selectedCoordinatorId = value);
                    },
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _savePastoral,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: azulPrimario,
                    ),
                    child: Text(
                      widget.pastoral == null
                          ? 'Salvar Pastoral'
                          : 'Atualizar Pastoral',
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
