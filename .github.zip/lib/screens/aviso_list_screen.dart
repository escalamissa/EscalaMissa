
import 'package:escala_missa/models/aviso.dart';
import 'package:escala_missa/services/aviso_service.dart';
import 'package:escala_missa/services/pdf_service.dart';
import 'package:escala_missa/services/profile_service.dart';
import 'package:escala_missa/models/user_profile.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:escala_missa/screens/aviso_form_screen.dart'; // Import the new form screen

class AvisoListScreen extends StatefulWidget {
  static const routeName = '/avisos'; // Define routeName for consistent navigation
  const AvisoListScreen({super.key});

  @override
  State<AvisoListScreen> createState() => _AvisoListScreenState();
}

class _AvisoListScreenState extends State<AvisoListScreen> {
  final AvisoService _avisoService = AvisoService();
  final ProfileService _profileService = ProfileService();
  final PdfService _pdfService = PdfService();
  List<Aviso> _avisos = []; // Changed to List<Aviso>
  UserProfile? _userProfile;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    setState(() {
      _isLoading = true;
    });
    try {
      _userProfile = await _profileService.getProfile();
      final avisos = await _avisoService.getAvisos();
      setState(() {
        _avisos = avisos;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar avisos: $e')),
        );
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _deleteAviso(String id) async {
    try {
      await _avisoService.deleteAviso(id);
      _fetchData(); // Refresh the list after deletion
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Aviso excluído com sucesso!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao excluir aviso: $e')),
        );
      }
    }
  }

  bool _canCreateAviso() {
    final userPerfil = _userProfile?.perfil;
    return userPerfil == 'admin' || userPerfil == 'padre' || userPerfil == 'coordenador';
  }

  bool _canExport() {
    final userPerfil = _userProfile?.perfil;
    return userPerfil == 'admin' || userPerfil == 'padre' || userPerfil == 'coordenador';
  }

  bool _canEditAviso() {
    final userPerfil = _userProfile?.perfil;
    return userPerfil == 'admin' || userPerfil == 'padre' || userPerfil == 'coordenador';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text('Mural de Avisos'),
        actions: [
          if (_canExport())
            IconButton(
              icon: const Icon(Icons.picture_as_pdf),
              onPressed: () => _pdfService.generateAvisosPdf(_avisos.map((e) => e.toMap()).toList()), // Convert Aviso to Map for PDF service
            ),
          if (_canCreateAviso())
            IconButton(
              icon: const Icon(Icons.add),
              onPressed: () => context.push(AvisoFormScreen.routeName), // Navigate to form for new aviso
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _avisos.isEmpty
              ? const Center(child: Text('Nenhum aviso publicado.'))
              : ListView.builder(
                  itemCount: _avisos.length,
                  itemBuilder: (context, index) {
                    final aviso = _avisos[index];
                    return Dismissible(
                      key: ValueKey(aviso.id),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        color: Colors.red,
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: const Icon(Icons.delete, color: Colors.white),
                      ),
                      confirmDismiss: (direction) async {
                        return await showDialog(
                          context: context,
                          builder: (ctx) => AlertDialog(
                            title: const Text('Confirmar Exclusão'),
                            content: const Text('Tem certeza que deseja excluir este aviso?'),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.of(ctx).pop(false),
                                child: const Text('Não'),
                              ),
                              TextButton(
                                onPressed: () => Navigator.of(ctx).pop(true),
                                child: const Text('Sim'),
                              ),
                            ],
                          ),
                        );
                      },
                      onDismissed: (direction) {
                        _deleteAviso(aviso.id!);
                      },
                      child: Card(
                        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                        child: ListTile(
                          title: Text(aviso.titulo),
                          subtitle: Text(
                              '${aviso.mensagem}\nPublicado em: ${DateFormat('dd/MM/yyyy HH:mm').format(aviso.criadoEm!)}'),
                          isThreeLine: true,
                          onTap: _canEditAviso()
                              ? () => context.push('${AvisoFormScreen.routeName}?id=${aviso.id}', extra: aviso)
                              : null, // Disable tap if not allowed to edit
                          trailing: _canEditAviso()
                              ? IconButton(
                                  icon: const Icon(Icons.edit),
                                  onPressed: () => context.push('${AvisoFormScreen.routeName}?id=${aviso.id}', extra: aviso),
                                )
                              : null, // Hide or disable edit button
                        ),
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _fetchData, // Keep refresh functionality
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
