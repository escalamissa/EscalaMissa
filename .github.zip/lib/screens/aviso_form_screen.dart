
import 'package:escala_missa/models/aviso.dart';
import 'package:escala_missa/models/parish.dart';
import 'package:escala_missa/models/pastoral.dart';
import 'package:escala_missa/services/aviso_service.dart';
import 'package:escala_missa/services/parish_service.dart';
import 'package:escala_missa/services/pastoral_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AvisoFormScreen extends StatefulWidget {
  static const routeName = '/avisos/form';
  final Aviso? aviso;

  const AvisoFormScreen({super.key, this.aviso});

  @override
  State<AvisoFormScreen> createState() => _AvisoFormScreenState();
}

class _AvisoFormScreenState extends State<AvisoFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final AvisoService _avisoService = AvisoService();
  final ParishService _parishService = ParishService();
  final PastoralService _pastoralService = PastoralService();

  late TextEditingController _tituloController;
  late TextEditingController _mensagemController;
  String? _selectedParishId;
  String? _selectedPastoralId;

  List<Parish> _parishes = [];
  List<Pastoral> _pastorals = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tituloController = TextEditingController(text: widget.aviso?.titulo ?? '');
    _mensagemController = TextEditingController(text: widget.aviso?.mensagem ?? '');
    if (widget.aviso != null) {
      _selectedParishId = widget.aviso!.paroquiaId;
      _selectedPastoralId = widget.aviso!.pastoralId;
    }
    _fetchDependencies();
  }

  @override
  void dispose() {
    _tituloController.dispose();
    _mensagemController.dispose();
    super.dispose();
  }

  Future<void> _fetchDependencies() async {
    setState(() {
      _isLoading = true;
    });
    try {
      _parishes = await _parishService.getParishes();
      _pastorals = await _pastoralService.getPastorais();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar dependências: $e')),
        );
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  void _saveAviso() async {
    if (_formKey.currentState!.validate()) {
      if (_selectedParishId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Por favor, selecione uma paróquia.')),
        );
        return;
      }

      final newAviso = Aviso(
        id: widget.aviso?.id,
        titulo: _tituloController.text,
        mensagem: _mensagemController.text,
        paroquiaId: _selectedParishId!,
        pastoralId: _selectedPastoralId,
        criadoPor: Supabase.instance.client.auth.currentUser!.id,
      );

      try {
        if (widget.aviso == null) {
          await _avisoService.createAviso(newAviso);
        } else {
          await _avisoService.updateAviso(newAviso);
        }
        if (mounted) {
          context.pop();
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Erro ao salvar aviso: $e')),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.aviso == null ? 'Novo Aviso' : 'Editar Aviso'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    TextFormField(
                      controller: _tituloController,
                      decoration: const InputDecoration(
                        labelText: 'Título',
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Por favor, insira um título';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16.0),
                    TextFormField(
                      controller: _mensagemController,
                      decoration: const InputDecoration(
                        labelText: 'Mensagem',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 5,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Por favor, insira a mensagem';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16.0),
                    DropdownButtonFormField<String>(
                      value: _selectedParishId,
                      decoration: const InputDecoration(labelText: 'Paróquia'),
                      items: _parishes.map((parish) {
                        return DropdownMenuItem(
                          value: parish.id,
                          child: Text(parish.nome),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedParishId = value;
                        });
                      },
                      validator: (value) =>
                          value == null ? 'Selecione uma paróquia' : null,
                    ),
                    const SizedBox(height: 16.0),
                    DropdownButtonFormField<String?>(
                      value: _selectedPastoralId,
                      decoration: const InputDecoration(labelText: 'Pastoral (Opcional)'),
                      items: [
                        const DropdownMenuItem<String?>(
                          value: null,
                          child: Text('Nenhuma'),
                        ),
                        ..._pastorals.map((pastoral) {
                          return DropdownMenuItem(
                            value: pastoral.id,
                            child: Text(pastoral.nome),
                          );
                        }).toList()
                      ],
                      onChanged: (value) {
                        setState(() {
                          _selectedPastoralId = value;
                        });
                      },
                    ),
                    const SizedBox(height: 24.0),
                    ElevatedButton(
                      onPressed: _saveAviso,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12.0),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                      child: Text(widget.aviso == null ? 'Salvar Aviso' : 'Atualizar Aviso'),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
