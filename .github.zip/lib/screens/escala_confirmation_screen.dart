import 'package:escala_missa/models/escala.dart';
import 'package:escala_missa/services/escala_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import 'package:escala_missa/services/notification_service.dart'; // Added import

class EscalaConfirmationScreen extends StatefulWidget {
  final Escala escala;
  final NotificationService notificationService; // Added

  const EscalaConfirmationScreen({super.key, required this.escala, required this.notificationService}); // Modified

  @override
  State<EscalaConfirmationScreen> createState() => _EscalaConfirmationScreenState();
}

class _EscalaConfirmationScreenState extends State<EscalaConfirmationScreen> {
  late EscalaService _escalaService; // Modified to be late and non-final
  bool _isConfirming = false;

  @override
  void initState() {
    super.initState();
    _escalaService = EscalaService(); // Initialized in initState
  }

  Future<void> _confirmEscala() async {
    setState(() {
      _isConfirming = true;
    });
    try {
      await _escalaService.updateEscalaStatus(
        id: widget.escala.id!,
        status: 'confirmado',
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Escala confirmada com sucesso!')),
        );
        context.pop(); // Go back after confirmation
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao confirmar escala: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isConfirming = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final DateTime eventDateTime = DateTime.parse(widget.escala.evento?.data_hora ?? '');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Confirmar Escala'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Detalhes da Escala:',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 16),
            _buildDetailRow('Evento:', widget.escala.evento?.titulo ?? 'N/A'),
            _buildDetailRow('Data e Hora:', DateFormat('dd/MM/yyyy HH:mm').format(eventDateTime)),
            _buildDetailRow('Pastoral:', widget.escala.pastoral?.nome ?? 'N/A'),
            _buildDetailRow('Função:', widget.escala.funcao?.name ?? 'N/A'),
            _buildDetailRow('Voluntário:', widget.escala.voluntario?.nome ?? 'N/A'),
            _buildDetailRow('Observação:', widget.escala.observation ?? 'Nenhuma'),
            const SizedBox(height: 32),
            _isConfirming
                ? const Center(child: CircularProgressIndicator())
                : ElevatedButton(
                    onPressed: _confirmEscala,
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 50),
                    ),
                    child: const Text('Confirmar Minha Escala'),
                  ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
