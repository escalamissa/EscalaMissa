
import 'package:escala_missa/services/personal_agenda_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

class PersonalAgendaScreen extends StatefulWidget {
  const PersonalAgendaScreen({super.key});

  @override
  State<PersonalAgendaScreen> createState() => _PersonalAgendaScreenState();
}

class _PersonalAgendaScreenState extends State<PersonalAgendaScreen> {
  final PersonalAgendaService _personalAgendaService = PersonalAgendaService();
  List<Map<String, dynamic>> _myEscalas = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchMyAgenda();
  }

  Future<void> _fetchMyAgenda() async {
    setState(() {
      _isLoading = true;
    });
    try {
      final escalas = await _personalAgendaService.getMyAgenda();
      setState(() {
        _myEscalas = escalas;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar sua agenda: $e')),
        );
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text('Minha Agenda'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _myEscalas.isEmpty
              ? const Center(child: Text('Nenhuma escala atribuída a você.'))
              : ListView.builder(
                  itemCount: _myEscalas.length,
                  itemBuilder: (context, index) {
                    final escala = _myEscalas[index];
                    final DateTime eventDateTime = DateTime.parse(escala['eventos']?['data_hora']);
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      child: ListTile(
                        title: Text(
                            '${escala['eventos']?['titulo'] ?? 'Evento'} - ${escala['funcoes']?['nome'] ?? 'Função'}'),
                        subtitle: Text(
                            '${DateFormat('dd/MM/yyyy HH:mm').format(eventDateTime)} - ${escala['pastorais']?['nome'] ?? 'Pastoral'}'),
                        trailing: Text(escala['status'] ?? ''),
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _fetchMyAgenda,
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
