import 'package:escala_missa/services/pastoral_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:escala_missa/models/pastoral.dart';

class PastoralListScreen extends StatefulWidget {
  static const routeName = '/admin/pastorals';
  const PastoralListScreen({super.key});

  @override
  State<PastoralListScreen> createState() => _PastoralListScreenState();
}

class _PastoralListScreenState extends State<PastoralListScreen> {
  final PastoralService _pastoralService = PastoralService();
  List<Pastoral> _pastorais = [];
  bool _isLoading = true;

  // --- Cores do Tema (para consistência) ---
  static const azulPrimario = Color(0xFF0050A0);
  static const textoPrincipal = Color(0xFF1C1C1C);

  @override
  void initState() {
    super.initState();
    _fetchPastorais();
  }

  Future<void> _fetchPastorais() async {
    setState(() => _isLoading = true);
    try {
      final pastorais = await _pastoralService.getPastorais();
      setState(() => _pastorais = pastorais);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar pastorais: $e')),
        );
      }
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text('Gerenciar Pastorais'),
        backgroundColor: azulPrimario,
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: 'Nova Pastoral',
            onPressed: () => context.push('/admin/pastorals/new'),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _pastorais.isEmpty
          ? const Center(child: Text('Nenhuma pastoral cadastrada.'))
          : RefreshIndicator(
              onRefresh: _fetchPastorais,
              child: ListView.builder(
                padding: const EdgeInsets.only(
                  top: 8.0,
                  bottom: 80.0,
                ), // Padding for FAB
                itemCount: _pastorais.length,
                itemBuilder: (context, index) {
                  final pastoral = _pastorais[index];
                  // --- CARD COM UI MELHORADA INTEGRADO AQUI ---
                  return Card(
                    elevation: 2,
                    margin: const EdgeInsets.symmetric(
                      vertical: 8,
                      horizontal: 16,
                    ),
                    shape: RoundedRectangleBorder(
                      side: BorderSide(color: Colors.grey.shade200),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: InkWell(
 onTap: () => context.push('/admin/pastorals/edit', extra: pastoral),
                      borderRadius: BorderRadius.circular(12),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              pastoral.nome,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: textoPrincipal,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Icon(
                                  Icons.church_outlined,
                                  size: 16,
                                  color: Colors.grey.shade600,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    'Paróquia: ${pastoral.paroquia?.nome ?? 'N/A'}',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.grey.shade700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Icon(
                                  Icons.person_outline,
                                  size: 16,
                                  color: Colors.grey.shade600,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    'Coordenador: ${pastoral.coordenador?.nome ?? 'Não definido'}',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.grey.shade700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => context.push('/admin/pastorals/new'),
        backgroundColor: azulPrimario,
        tooltip: 'Adicionar Pastoral',
        child: const Icon(Icons.add),
      ),
    );
  }
}
