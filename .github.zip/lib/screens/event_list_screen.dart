import 'package:escala_missa/services/event_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:escala_missa/models/event.dart'; // Added import
import 'package:intl/intl.dart'; // For date formatting
import 'package:escala_missa/services/pdf_service.dart';

class EventListScreen extends StatefulWidget {
  static const routeName = '/admin/events';
  const EventListScreen({super.key});

  @override
  State<EventListScreen> createState() => _EventListScreenState();
}

class _EventListScreenState extends State<EventListScreen> {
  final EventService _eventService = EventService();
  final PdfService _pdfService = PdfService();
  List<Evento> _events = [];
  bool _isLoading = true;

  bool _canExport() => true;

  @override
  void initState() {
    super.initState();
    _fetchEvents();
  }

  Future<void> _fetchEvents() async {
    setState(() {
      _isLoading = true;
    });
    try {
      final events = await _eventService.getEvents();
      setState(() {
        _events = events;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Erro ao carregar eventos: $e')));
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text('Gerenciar Eventos'),
        actions: [
          if (_canExport())
            IconButton(
              icon: const Icon(Icons.picture_as_pdf),
              onPressed: () => _pdfService.generateEventsPdf(
                _events.map((e) => e.toMap()).toList(),
              ),
            ),
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => context.push('/admin/events/new'),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _events.isEmpty
          ? const Center(child: Text('Nenhum evento cadastrado.'))
          : ListView.builder(
              itemCount: _events.length,
              itemBuilder: (context, index) {
                final event = _events[index];
                final DateTime eventDateTime = DateTime.parse(event.data_hora);
                return Card(
                  margin: const EdgeInsets.symmetric(
                    vertical: 8,
                    horizontal: 16,
                  ),
                  child: ListTile(
                    title: Text(event.titulo),
                    subtitle: Text(
                      '${DateFormat('dd/MM/yyyy HH:mm').format(eventDateTime)}',
                    ), // Removed parish name for now
                    // onTap: () => context.go('/admin/events/${event.id}', extra: event), // For editing
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _fetchEvents,
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
