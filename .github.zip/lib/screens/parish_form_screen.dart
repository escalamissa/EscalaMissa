
import 'package:escala_missa/models/parish.dart'; // Import Parish model
import 'package:escala_missa/services/parish_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class ParishFormScreen extends StatefulWidget {
  final Parish? parish; // Optional Parish for editing
  const ParishFormScreen({super.key, this.parish});

  @override
  State<ParishFormScreen> createState() => _ParishFormScreenState();
}

class _ParishFormScreenState extends State<ParishFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _cityController;
  late TextEditingController _ufController;
  final ParishService _parishService = ParishService();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.parish?.nome ?? '');
    _cityController = TextEditingController(text: widget.parish?.cidade ?? '');
    _ufController = TextEditingController(text: widget.parish?.uf ?? '');
  }

  Future<void> _saveParish() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      try {
        final parish = Parish(
          id: widget.parish?.id,
          nome: _nameController.text.trim(),
          cidade: _cityController.text.trim(),
          uf: _ufController.text.trim(),
        );

        if (widget.parish == null) {
          await _parishService.createParish(parish);
        } else {
          await _parishService.updateParish(parish);
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Paróquia salva com sucesso!')),
          );
          context.pop(); // Go back to list after saving
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Erro ao salvar paróquia: $e')),
          );
        }
      }
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _cityController.dispose();
    _ufController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.parish == null ? 'Nova Paróquia' : 'Editar Paróquia'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(16.0),
                children: [
                  TextFormField(
                    controller: _nameController,
                    decoration: const InputDecoration(labelText: 'Nome da Paróquia'),
                    validator: (value) =>
                        value!.isEmpty ? 'Por favor, insira o nome da paróquia' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _cityController,
                    decoration: const InputDecoration(labelText: 'Cidade'),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _ufController,
                    decoration: const InputDecoration(labelText: 'UF'),
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _saveParish,
                    child: Text(widget.parish == null ? 'Salvar Paróquia' : 'Atualizar Paróquia'),
                  ),
                ],
              ),
            ),
    );
  }
}
