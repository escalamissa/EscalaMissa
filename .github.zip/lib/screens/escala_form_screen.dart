import 'package:escala_missa/services/escala_service.dart';
import 'package:escala_missa/services/event_service.dart';
import 'package:escala_missa/services/function_service.dart';
import 'package:escala_missa/services/pastoral_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:escala_missa/models/event.dart'; // Added import
import 'package:escala_missa/models/pastoral.dart'; // Added import
import 'package:escala_missa/models/app_function.dart'; // Added import
import 'package:escala_missa/models/escala.dart' show Escala; // Reverted import

import 'package:escala_missa/services/notification_service.dart'; // Added import

class EscalaFormScreen extends StatefulWidget {
  final Escala? escala;
  final NotificationService notificationService; // Added
  const EscalaFormScreen({super.key, this.escala, required this.notificationService}); // Modified

  @override
  State<EscalaFormScreen> createState() => _EscalaFormScreenState();
}

class _EscalaFormScreenState extends State<EscalaFormScreen> {
  final _formKey = GlobalKey<FormState>();
  String? _selectedEventId;
  String? _selectedPastoralId;
  String? _selectedFunctionId;
  String? _selectedVoluntarioId;
  final _observacaoController = TextEditingController();

  late EscalaService _escalaService; // Modified to be late and non-final
  final EventService _eventService = EventService();
  final PastoralService _pastoralService = PastoralService();
  final FunctionService _functionService = FunctionService();

  List<Evento> _events = []; // Changed to List<Event>
  List<Pastoral> _pastorals = []; // Changed to List<Pastoral>
  List<AppFunction> _functions = []; // Changed to List<AppFunction>
  List<Map<String, dynamic>> _volunteers = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _escalaService = EscalaService(); // Initialized in initState
    _fetchDependencies();
  }

  Future<void> _fetchDependencies() async {
    setState(() {
      _isLoading = true;
    });
    try {
      _events = await _eventService.getEvents();
      print('EscalaFormScreen: Fetched Events: ${_events.length}');
      _events.forEach(
        (event) => print('  Event: ${event.titulo} (ID: ${event.id})'),
      );

      _pastorals = await _pastoralService.getPastorais();
      print('EscalaFormScreen: Fetched Pastorals: ${_pastorals.length}');
      _pastorals.forEach(
        (pastoral) =>
            print('  Pastoral: ${pastoral.nome} (ID: ${pastoral.id})'),
      );

      final fetchedFunctions = await _functionService.getFunctions();
      _functions = fetchedFunctions
          .map((funcMap) => AppFunction.fromMap(funcMap))
          .toList();
      print('EscalaFormScreen: Fetched Functions: ${_functions.length}');
      _functions.forEach(
        (func) => print('  Function: ${func.name} (ID: ${func.id})'),
      );

      _volunteers = await Supabase.instance.client
          .from('users')
          .select()
          .eq('perfil', 'voluntario'); // Only volunteers for now
      print('EscalaFormScreen: Fetched Volunteers: ${_volunteers.length}');
      _volunteers.forEach(
        (volunteer) =>
            print('  Volunteer: ${volunteer['nome']} (ID: ${volunteer['id']})'),
      );

      if (widget.escala != null) {
        _selectedEventId = widget.escala!.eventId;
        if (_events.every((e) => e.id != _selectedEventId)) {
          _selectedEventId = null;
        }

        _selectedPastoralId = widget.escala!.pastoralId;
        if (_pastorals.every((p) => p.id != _selectedPastoralId)) {
          _selectedPastoralId = null;
        }

        _selectedFunctionId = widget.escala!.functionId;
        if (_functions.every((f) => f.id != _selectedFunctionId)) {
          _selectedFunctionId = null;
        }

        _selectedVoluntarioId = widget.escala!.volunteerId;
        if (_volunteers.every((v) => v['id'].toString() != _selectedVoluntarioId)) {
          _selectedVoluntarioId = null;
        }
        
        _observacaoController.text = widget.escala!.observation ?? '';
        
        print('EscalaFormScreen: Initializing with escala: ${widget.escala}');
        print('EscalaFormScreen: _selectedEventId: $_selectedEventId');
        print('EscalaFormScreen: _selectedPastoralId: $_selectedPastoralId');
        print('EscalaFormScreen: _selectedFunctionId: $_selectedFunctionId');
        print(
          'EscalaFormScreen: _selectedVoluntarioId: $_selectedVoluntarioId',
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar dependências: $e')),
        );
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _saveEscala() async {
    if (_formKey.currentState!.validate()) {
      if (_selectedEventId == null ||
          _selectedPastoralId == null ||
          _selectedFunctionId == null ||
          _selectedVoluntarioId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Por favor, preencha todos os campos obrigatórios.'),
          ),
        );
        return;
      }

      final parishId = _getParishIdFromSelectedPastoral();
      if (parishId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Não foi possível determinar a paróquia da pastoral selecionada.',
            ),
          ),
        );
        return;
      }

      final newEscala = Escala(
        id: widget.escala?.id,
        eventId: _selectedEventId!,
        pastoralId: _selectedPastoralId!,
        functionId: _selectedFunctionId!,
        volunteerId: _selectedVoluntarioId!,
        paroquiaId: parishId,
        observation: _observacaoController.text.trim(),
      );

      setState(() {
        _isLoading = true;
      });
      try {
        if (widget.escala == null) {
          // Create new escala
          await _escalaService.createEscala(newEscala);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Escala salva com sucesso!')),
            );
            context.pop(); // Go back to list after saving
          }
        } else {
          // Update existing escala
          await _escalaService.updateEscala(newEscala);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Escala atualizada com sucesso!')),
            );
            context.pop(); // Go back to list after saving
          }
        }
      } on Exception catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text('Erro ao salvar escala: $e')));
        }
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  String? _getParishIdFromSelectedPastoral() {
    if (_selectedPastoralId == null) return null;
    final selectedPastoral = _pastorals.firstWhere(
      (p) => p.id == _selectedPastoralId,
      orElse: () => throw Exception('Selected pastoral not found'),
    );
    return selectedPastoral.paroquiaId;
  }

  @override
  void dispose() {
    _observacaoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.escala == null ? 'Nova Escala' : 'Editar Escala'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(16.0),
                children: [
                  DropdownButtonFormField<String>(
                    value: _selectedEventId,
                    decoration: const InputDecoration(labelText: 'Evento'),
                    items: _events.map((event) {
                      print(
                        '  Dropdown Event Item: ${event.titulo} (ID: ${event.id})',
                      );
                      return DropdownMenuItem(
                        value: event.id,
                        child: Text(event.titulo),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedEventId = value;
                      });
                    },
                    validator: (value) =>
                        value == null ? 'Selecione um evento' : null,
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: _selectedPastoralId,
                    decoration: const InputDecoration(labelText: 'Pastoral'),
                    items: _pastorals.map((pastoral) {
                      print(
                        '  Dropdown Pastoral Item: ${pastoral.nome} (ID: ${pastoral.id})',
                      );
                      return DropdownMenuItem(
                        value: pastoral.id,
                        child: Text(pastoral.nome),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedPastoralId = value;
                      });
                    },
                    validator: (value) =>
                        value == null ? 'Selecione uma pastoral' : null,
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: _selectedFunctionId,
                    decoration: const InputDecoration(labelText: 'Função'),
                    items: _functions.map((func) {
                      print(
                        '  Dropdown Function Item: ${func.name} (ID: ${func.id})',
                      );
                      return DropdownMenuItem(
                        value: func.id,
                        child: Text(func.name),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedFunctionId = value;
                      });
                    },
                    validator: (value) =>
                        value == null ? 'Selecione uma função' : null,
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: _selectedVoluntarioId,
                    decoration: const InputDecoration(labelText: 'Voluntário'),
                    items: _volunteers.map((volunteer) {
                      print(
                        '  Dropdown Volunteer Item: ${volunteer['nome']} (ID: ${volunteer['id']})',
                      );
                      return DropdownMenuItem(
                        value: volunteer['id'] as String,
                        child: Text(volunteer['nome'] as String),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedVoluntarioId = value;
                      });
                    },
                    validator: (value) =>
                        value == null ? 'Selecione um voluntário' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _observacaoController,
                    decoration: const InputDecoration(
                      labelText: 'Observação (Opcional)',
                    ),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _saveEscala,
                    child: const Text('Salvar Escala'),
                  ),
                ],
              ),
            ),
    );
  }
}
