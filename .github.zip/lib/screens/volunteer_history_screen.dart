
import 'package:escala_missa/services/volunteer_history_service.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

class VolunteerHistoryScreen extends StatefulWidget {
  static const routeName = '/history';
  const VolunteerHistoryScreen({super.key});

  @override
  State<VolunteerHistoryScreen> createState() => _VolunteerHistoryScreenState();
}

class _VolunteerHistoryScreenState extends State<VolunteerHistoryScreen> {
  final VolunteerHistoryService _volunteerHistoryService = VolunteerHistoryService();
  List<Map<String, dynamic>> _history = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchHistory();
  }

  Future<void> _fetchHistory() async {
    setState(() {
      _isLoading = true;
    });
    try {
      final history = await _volunteerHistoryService.getMyParticipationHistory();
      setState(() {
        _history = history;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar histórico: $e')),
        );
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            context.pop();
          },
        ),
        title: const Text('Meu Histórico de Participação'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _history.isEmpty
              ? const Center(child: Text('Nenhuma participação registrada.'))
              : ListView.builder(
                  itemCount: _history.length,
                  itemBuilder: (context, index) {
                    final escala = _history[index];
                    final DateTime eventDateTime = DateTime.parse(escala['eventos']?['data_hora']);
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      child: ListTile(
                        title: Text(
                            '${escala['eventos']?['titulo'] ?? 'Evento'} - ${escala['funcoes']?['nome'] ?? 'Função'}'),
                        subtitle: Text(
                            '${DateFormat('dd/MM/yyyy HH:mm').format(eventDateTime)} - ${escala['pastorais']?['nome'] ?? 'Pastoral'} (Status: ${escala['status'] ?? 'N/A'})'),
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _fetchHistory,
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
