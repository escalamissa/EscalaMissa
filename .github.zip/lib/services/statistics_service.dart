
import 'package:supabase_flutter/supabase_flutter.dart';

class StatisticsService {
  final _client = Supabase.instance.client;

  Future<int> getTotalEvents() async {
    final response = await _client.from('eventos').count(CountOption.exact);
    return response;
  }

  Future<int> getTotalScales() async {
    final response = await _client.from('escalas').count(CountOption.exact);
    return response;
  }

  Future<int> getConfirmedScales() async {
    final response = await _client.from('escalas').select('count').eq('status', 'confirmado').single();
    return response['count'] as int;
  }

  Future<int> getTotalUsers() async {
    final response = await _client.from('users').count(CountOption.exact);
    return response;
  }

  Future<int> getTotalVolunteers() async {
    final response = await _client.from('users').select('count').eq('perfil', 'voluntario').single();
    return response['count'] as int;
  }

  // Add more specific statistics as needed
}
